Simulation study for Bayesian hierarchical model.

R package longTransients must be installed:

  install.packages("path/to/longTransients_1.0.tar.gz", repos = NULL)

The simulation_study.R script fits both models to several subsets of the 10 simulated trajectories for a single value of the measurement error variance.

The single_realization.R script fits both models to one subset of the simulated trajectories.

STILL TO DO: implement KL divergence that Kai developed. 